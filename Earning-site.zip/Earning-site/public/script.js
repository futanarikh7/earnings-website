// Earnings Platform - Main Logic
class EarningsPlatform {
    constructor() {
        this.userData = {
            balance: 0,
            adsWatched: 0,
            totalEarned: 0,
            todayEarned: 0,
            referralEarnings: 0,
            lastAdTime: 0,
            userId: this.generateUserId(),
            referralCode: this.generateReferralCode()
        };
        
        this.adRewards = {
            short: 0.05,    // $0.05 for 30s ad
            medium: 0.10,   // $0.10 for 60s ad
            long: 0.20      // $0.20 for 120s ad
        };
        
        this.currentAdType = 'short';
        this.isWatching = false;
        this.adTimer = null;
        this.timeLeft = 30;
    }
    
    // Initialize
    init() {
        this.loadUserData();
        this.updateUI();
        this.startLiveStats();
        this.setupServiceWorker();
    }
    
    // Generate unique user ID
    generateUserId() {
        return 'user_' + Math.random().toString(36).substr(2, 9);
    }
    
    // Generate referral code
    generateReferralCode() {
        return 'REF' + Math.random().toString(36).substr(2, 6).toUpperCase();
    }
    
    // Load user data from localStorage
    loadUserData() {
        const saved = localStorage.getItem('earningsUserData');
        if (saved) {
            const parsed = JSON.parse(saved);
            this.userData = { ...this.userData, ...parsed };
        } else {
            this.saveUserData();
        }
        
        // Update referral link
        document.getElementById('refCode').textContent = this.userData.referralCode;
    }
    
    // Save user data
    saveUserData() {
        localStorage.setItem('earningsUserData', JSON.stringify(this.userData));
        
        // Also save to serverless function (optional)
        this.syncWithServer();
    }
    
    // Sync with Vercel serverless function
    async syncWithServer() {
        try {
            await fetch('/api/save-data', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(this.userData)
            });
        } catch (error) {
            console.log('Sync failed, using localStorage only');
        }
    }
    
    // Start watching ad
    startWatching() {
        if (this.isWatching) return;
        
        // Check cooldown (30 seconds between ads)
        const now = Date.now();
        if (now - this.userData.lastAdTime < 30000) {
            this.showNotification('Please wait 30 seconds between ads', 'warning');
            return;
        }
        
        // Reset timer
        this.timeLeft = 30;
        this.isWatching = true;
        this.currentAdType = 'short';
        
        // Update UI
        document.getElementById('watchBtn').disabled = true;
        document.getElementById('watchBtn').innerHTML = '<i class="fas fa-spinner fa-spin"></i> WATCHING...';
        document.getElementById('timer').textContent = this.timeLeft;
        
        // Show ad simulation
        this.showAdSimulation();
        
        // Start countdown
        this.startCountdown();
        
        // Track start
        this.trackEvent('ad_start', { type: this.currentAdType });
    }
    
    // Show ad simulation
    showAdSimulation() {
        const videoPlayer = document.getElementById('videoPlayer');
        const adReward = this.adRewards[this.currentAdType];
        
        videoPlayer.innerHTML = `
            <div style="width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; position: relative;">
                <!-- Fake ad content -->
                <div style="text-align: center; color: white; padding: 20px; max-width: 80%;">
                    <div style="font-size: 3rem; margin-bottom: 20px;">🎬</div>
                    <h2 style="margin-bottom: 10px;">Advertisement</h2>
                    <p style="opacity: 0.8; margin-bottom: 20px;">This is a simulated advertisement</p>
                    <div style="background: rgba(255,255,255,0.1); padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                        <p style="margin: 0; font-size: 0.9rem;">Ad supports your earnings</p>
                    </div>
                    <div style="display: flex; align-items: center; justify-content: center; gap: 10px;">
                        <div style="font-size: 1.5rem;">💰</div>
                        <div style="font-size: 1.2rem;">Earning: $${adReward.toFixed(2)}</div>
                    </div>
                </div>
                
                <!-- Fake ad overlay -->
                <div style="position: absolute; bottom: 20px; right: 20px; background: rgba(0,0,0,0.7); padding: 8px 15px; border-radius: 20px; font-size: 0.9rem;">
                    Ad • 1 of 1
                </div>
                
                <!-- Skip button (fake) -->
                <div style="position: absolute; top: 20px; right: 20px; background: rgba(255,255,255,0.1); padding: 8px 15px; border-radius: 5px; font-size: 0.9rem;">
                    Skip in 5s
                </div>
            </div>
        `;
        
        // Update earning info
        document.getElementById('earningInfo').textContent = 
            `Earn $${adReward.toFixed(2)} for watching this ad`;
    }
    
    // Start countdown timer
    startCountdown() {
        this.adTimer = setInterval(() => {
            this.timeLeft--;
            document.getElementById('timer').textContent = this.timeLeft;
            
            // Update progress bar
            const progress = ((30 - this.timeLeft) / 30) * 100;
            document.getElementById('adLoadProgress').style.width = `${progress}%`;
            
            if (this.timeLeft <= 0) {
                this.completeAd();
            }
        }, 1000);
    }
    
    // Complete ad viewing
    completeAd() {
        clearInterval(this.adTimer);
        this.isWatching = false;
        
        // Calculate earnings
        const reward = this.adRewards[this.currentAdType];
        this.userData.balance += reward;
        this.userData.totalEarned += reward;
        this.userData.todayEarned += reward;
        this.userData.adsWatched++;
        this.userData.lastAdTime = Date.now();
        
        // Save data
        this.saveUserData();
        
        // Update UI
        this.updateUI();
        
        // Reset button
        document.getElementById('watchBtn').disabled = false;
        document.getElementById('watchBtn').innerHTML = '<i class="fas fa-play"></i> START EARNING NOW';
        
        // Show success modal
        this.showSuccessModal(reward);
        
        // Reset video player
        setTimeout(() => {
            document.getElementById('videoPlayer').innerHTML = `
                <div style="text-align: center; color: white; padding: 40px;">
                    <div style="font-size: 4rem; margin-bottom: 20px;">✅</div>
                    <h2 style="margin-bottom: 10px;">Ad Complete!</h2>
                    <p>Ready to watch another ad?</p>
                </div>
            `;
        }, 2000);
        
        // Track completion
        this.trackEvent('ad_complete', { 
            type: this.currentAdType, 
            reward: reward 
        });
    }
    
    // Show success modal
    showSuccessModal(reward) {
        document.getElementById('modalMessage').textContent = 
            `You earned $${reward.toFixed(2)}! Your balance is now $${this.userData.balance.toFixed(2)}`;
        
        document.getElementById('successModal').style.display = 'flex';
        
        // Auto-close after 5 seconds
        setTimeout(() => {
            this.closeModal();
        }, 5000);
    }
    
    // Close modal
    closeModal() {
        document.getElementById('successModal').style.display = 'none';
    }
    
    // Update all UI elements
    updateUI() {
        // Balance
        document.getElementById('userBalance').textContent = 
            `$${this.userData.balance.toFixed(2)}`;
        
        // Stats
        document.getElementById('adsWatched').textContent = 
            this.userData.adsWatched.toLocaleString();
        
        document.getElementById('totalEarned').textContent = 
            `$${this.userData.totalEarned.toFixed(2)}`;
        
        document.getElementById('todayEarned').textContent = 
            `$${this.userData.todayEarned.toFixed(2)}`;
        
        document.getElementById('referralEarnings').textContent = 
            `$${this.userData.referralEarnings.toFixed(2)}`;
    }
    
    // Redeem reward
    redeemReward(type, amount) {
        if (this.userData.balance < amount) {
            this.showNotification(`Minimum balance required: $${amount.toFixed(2)}`, 'error');
            return;
        }
        
        // Show withdrawal form
        const email = prompt(`Enter your ${type} email/address for $${amount} withdrawal:`);
        
        if (email) {
            this.userData.balance -= amount;
            this.saveUserData();
            this.updateUI();
            
            this.showNotification(
                `Withdrawal request for $${amount} submitted! Processing time: 24 hours.`,
                'success'
            );
            
            // Track redemption
            this.trackEvent('withdrawal_request', { type, amount });
        }
    }
    
    // Copy referral link
    copyReferralLink() {
        const link = document.getElementById('referralLink').textContent;
        navigator.clipboard.writeText(link)
            .then(() => {
                this.showNotification('Referral link copied!', 'success');
            })
            .catch(() => {
                // Fallback
                const textArea = document.createElement('textarea');
                textArea.value = link;
                document.body.appendChild(textArea);
                textArea.select();
                document.execCommand('copy');
                document.body.removeChild(textArea);
                this.showNotification('Referral link copied!', 'success');
            });
    }
    
    // Start live stats animation
    startLiveStats() {
        // Animate stats
        setInterval(() => {
            const totalPayouts = document.getElementById('totalPayouts');
            const activeUsers = document.getElementById('activeUsers');
            
            // Increment stats slightly for realism
            const currentPayouts = parseInt(totalPayouts.textContent.replace('$', '').replace(',', ''));
            const currentUsers = parseInt(activeUsers.textContent.replace(',', ''));
            
            totalPayouts.textContent = `$${(currentPayouts + Math.random() * 10).toLocaleString('en-US', {
                minimumFractionDigits: 0,
                maximumFractionDigits: 0
            })}`;
            
            activeUsers.textContent = (currentUsers + Math.random() * 5).toLocaleString('en-US', {
                minimumFractionDigits: 0,
                maximumFractionDigits: 0
            });
        }, 10000); // Update every 10 seconds
    }
    
    // Show notification
    showNotification(message, type = 'info') {
        const colors = {
            success: '#10b981',
            error: '#ef4444',
            warning: '#f59e0b',
            info: '#3b82f6'
        };
        
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${colors[type]};
            color: white;
            padding: 15px 25px;
            border-radius: 10px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            z-index: 1000;
            animation: slideIn 0.3s ease;
            max-width: 300px;
        `;
        
        notification.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-${type === 'success' ? 'check-circle' : 
                                type === 'error' ? 'exclamation-circle' : 
                                type === 'warning' ? 'exclamation-triangle' : 'info-circle'}"></i>
                <span>${message}</span>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Remove after 5 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 5000);
    }
    
    // Track events (for analytics)
    trackEvent(event, data = {}) {
        // Send to serverless function
        fetch('/api/track-event', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ event, data, userId: this.userData.userId })
        }).catch(() => {});
        
        // Google Analytics
        if (window.gtag) {
            gtag('event', event, data);
        }
    }
    
    // Setup service worker for PWA
    setupServiceWorker() {
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/sw.js')
                .then(() => console.log('Service Worker registered'))
                .catch(err => console.log('SW registration failed:', err));
        }
    }
}

// Initialize platform
const platform = new EarningsPlatform();

// Make functions available globally
window.startWatching = () => platform.startWatching();
window.redeemReward = (type, amount) => platform.redeemReward(type, amount);
window.copyReferralLink = () => platform.copyReferralLink();
window.closeModal = () => platform.closeModal();

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    platform.init();
    
    // Add animation styles
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    document.head.appendChild(style);
});