// Alternative Ad Networks Manager for Vercel
class AdManager {
    constructor() {
        this.networks = [
            {
                name: 'PropellerAds',
                script: '//pl21229283.highrevenuegate.com/5f/2a/bf/5f2abf7ae2f81b1f928d55c264f2ddb9.js',
                type: 'popunder',
                minPayout: 5
            },
            {
                name: 'Adsterra',
                script: '//www.highperformanceformat.com/YOUR_KEY/invoke.js',
                type: 'banner',
                minPayout: 5
            },
            {
                name: 'Media.net',
                script: '//contextual.media.net/dmedianet.js?cid=YOUR_CID',
                type: 'contextual',
                minPayout: 10
            }
        ];
        
        this.currentAd = 0;
        this.adElements = ['ad1', 'ad2'];
    }
    
    // Initialize ads
    init() {
        this.loadAdNetwork();
        this.rotateAds();
        
        // Load ads after page load
        setTimeout(() => this.showAds(), 2000);
    }
    
    // Load ad network script
    loadAdNetwork() {
        const network = this.networks[0]; // Start with first network
        
        // Only load if not already loaded
        if (!document.querySelector(`script[src*="${network.name}"]`)) {
            const script = document.createElement('script');
            script.src = `https:${network.script}`;
            script.async = true;
            script.onload = () => console.log(`${network.name} loaded`);
            document.head.appendChild(script);
        }
    }
    
    // Show ads in containers
    showAds() {
        this.adElements.forEach((id, index) => {
            const container = document.getElementById(id);
            if (container) {
                container.innerHTML = this.createAdHTML(index);
            }
        });
    }
    
    // Create ad HTML
    createAdHTML(index) {
        const networks = [
            {
                html: `
                    <div style="text-align: center; padding: 20px;">
                        <div style="font-size: 2rem; color: #6366f1; margin-bottom: 15px;">
                            <i class="fas fa-ad"></i>
                        </div>
                        <h3 style="color: #1f2937; margin-bottom: 10px;">Advertisement</h3>
                        <p style="color: #6b7280; margin-bottom: 20px;">
                            This ad supports free earnings on our platform
                        </p>
                        <div style="background: #f3f4f6; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                            <p style="margin: 0; color: #4b5563; font-size: 0.9rem;">
                                <i class="fas fa-info-circle"></i> Please disable ad blocker to see ads
                            </p>
                        </div>
                        <button onclick="adManager.handleAdClick(${index})" style="
                            background: #6366f1;
                            color: white;
                            border: none;
                            padding: 10px 20px;
                            border-radius: 8px;
                            cursor: pointer;
                            font-weight: 600;
                        ">
                            <i class="fas fa-external-link-alt"></i> Visit Advertiser
                        </button>
                    </div>
                `
            },
            {
                html: `
                    <div style="text-align: center; padding: 20px;">
                        <div style="display: flex; align-items: center; justify-content: center; gap: 15px; margin-bottom: 20px;">
                            <div style="font-size: 1.5rem; color: #10b981;">
                                <i class="fas fa-bullhorn"></i>
                            </div>
                            <div style="font-size: 1.5rem; color: #8b5cf6;">
                                <i class="fas fa-chart-line"></i>
                            </div>
                            <div style="font-size: 1.5rem; color: #f59e0b;">
                                <i class="fas fa-star"></i>
                            </div>
                        </div>
                        <h3 style="color: #1f2937; margin-bottom: 10px;">Sponsored Content</h3>
                        <p style="color: #6b7280; margin-bottom: 15px;">
                            Discover great products and services
                        </p>
                        <div style="
                            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                            color: white;
                            padding: 12px 25px;
                            border-radius: 8px;
                            display: inline-block;
                            margin-top: 10px;
                        ">
                            <i class="fas fa-gift"></i> Special Offer Inside
                        </div>
                    </div>
                `
            }
        ];
        
        return networks[index % networks.length].html;
    }
    
    // Handle ad click
    handleAdClick(adIndex) {
        // Track click
        if (window.platform) {
            platform.trackEvent('ad_click', { adIndex });
        }
        
        // Show message
        alert('Thank you for supporting our platform! Ad clicks help us provide free earning opportunities.');
        
        // Simulate opening advertiser page
        setTimeout(() => {
            window.open('https://example.com', '_blank');
        }, 500);
    }
    
    // Rotate ads every 30 seconds
    rotateAds() {
        setInterval(() => {
            this.currentAd = (this.currentAd + 1) % this.networks.length;
            this.showAds();
        }, 30000);
    }
    
    // Check for ad blocker
    detectAdBlocker() {
        const testAd = document.createElement('div');
        testAd.className = 'adsbox';
        testAd.style.cssText = 'position: absolute; left: -999px; top: -999px; width: 1px; height: 1px;';
        document.body.appendChild(testAd);
        
        setTimeout(() => {
            const isBlocked = testAd.offsetHeight === 0;
            testAd.remove();
            
            if (isBlocked) {
                this.showAdBlockerWarning();
            }
        }, 100);
    }
    
    // Show ad blocker warning
    showAdBlockerWarning() {
        const warning = document.createElement('div');
        warning.id = 'adblock-warning';
        warning.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: #f59e0b;
            color: white;
            padding: 15px;
            text-align: center;
            z-index: 9999;
            font-weight: 600;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        `;
        warning.innerHTML = `
            <div style="display: flex; align-items: center; justify-content: center; gap: 10px;">
                <i class="fas fa-exclamation-triangle"></i>
                <span>Ad blocker detected! Please disable it to earn money from watching ads.</span>
                <button onclick="this.parentElement.parentElement.remove()" style="
                    background: white;
                    color: #f59e0b;
                    border: none;
                    padding: 5px 15px;
                    border-radius: 5px;
                    margin-left: 20px;
                    cursor: pointer;
                    font-weight: 600;
                ">
                    Dismiss
                </button>
            </div>
        `;
        document.body.appendChild(warning);
    }
}

// Initialize ad manager
const adManager = new AdManager();

// Make available globally
window.adManager = adManager;

// Initialize ads when page loads
window.addEventListener('load', () => {
    setTimeout(() => {
        adManager.init();
        adManager.detectAdBlocker();
    }, 1000);
});