// Vercel Serverless Function: /api/earn.js
// This runs on Vercel's servers, NOT on GitHub Pages

export default async function handler(req, res) {
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    
    // Handle preflight
    if (req.method === 'OPTIONS') {
        return res.status(200).end();
    }
    
    try {
        const { action, userId, data } = req.body;
        
        switch (action) {
            case 'track_earnings':
                // Store earnings in database (in production)
                // For demo, just return success
                return res.status(200).json({
                    success: true,
                    message: 'Earnings tracked',
                    balance: data.balance || 0
                });
                
            case 'withdraw_request':
                // Process withdrawal (in production, integrate with PayPal/Stripe)
                return res.status(200).json({
                    success: true,
                    message: 'Withdrawal request received',
                    processingTime: '24 hours'
                });
                
            case 'get_stats':
                // Return fake stats for demo
                return res.status(200).json({
                    totalPayouts: 42583,
                    activeUsers: 18492,
                    avgEarnings: 3.72
                });
                
            default:
                return res.status(200).json({
                    success: true,
                    message: 'API is working',
                    timestamp: new Date().toISOString()
                });
        }
    } catch (error) {
        console.error('API error:', error);
        return res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
}